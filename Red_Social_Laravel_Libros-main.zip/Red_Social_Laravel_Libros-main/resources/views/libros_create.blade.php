<div class="container">
    <h1>Creación de libro</h1>

    <form action="{{ route('libros.store') }}" method="POST">
        @csrf
        
        <p>Título: <input type="text" name="Título" value="{{ old('Título') }}"></p>
        @foreach ($errors->get('Título') as $error)
            <div style="color: red;">{{$error}}</div>
        @endforeach

        <p>ID del Autor: <input type="number" name="Autor_id" value="{{ old('Autor_id') }}"></p>
        @foreach ($errors->get('Autor_id') as $error)
            <div style="color: red;">{{$error}}</div>
        @endforeach

        <p>Género: <input type="text" name="Género" value="{{ old('Género') }}"></p>
        <p>Editorial: <input type="text" name="Editorial" value="{{ old('Editorial') }}"></p>
        <p>Páginas: <input type="number" name="Páginas" value="{{ old('Páginas') }}"></p>
        
        <p>Fecha de publicación: <input type="date" name="Año" value="{{ old('Año') }}"></p>
        
        <p>Precio (€): <input type="number" step="0.01" name="Precio" value="{{ old('Precio') }}"></p>

        <input type="submit" value="Enviar" style="margin-top: 10px;">
    </form>

    <br>
    <a href="{{ route('libros.index') }}">Volver</a>
</div>
