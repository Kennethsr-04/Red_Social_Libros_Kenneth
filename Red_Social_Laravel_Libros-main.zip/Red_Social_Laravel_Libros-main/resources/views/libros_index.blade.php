<div class="container">
    <h2>Listado de Libros</h2>

    <div style="margin-bottom: 20px;">
        <a href="{{ route('libros.create') }}">Añadir Nuevo Libro</a>
    </div>
    
    <ul>
        @foreach($libros as $libro)
            <li style="margin-bottom: 10px;">
                <a href="{{ route('libros.show', $libro->Id) }}" style="text-decoration: underline; color: blue;">
                    {{ $libro->Título }}
                </a>
            </li>
        @endforeach
    </ul>
</div>
<a href="/usuarios">Volver</a>
