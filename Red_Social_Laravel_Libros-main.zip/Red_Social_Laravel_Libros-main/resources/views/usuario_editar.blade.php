<h1>Edición de usuario</h1>

<form action="/usuario/{{$usuario->id}}" method="POST"> <!-- No deja poner el PUT así, hay que poner el PUT después -->
    @csrf
    @method('PUT')
    <p>Nombre:      <input type="text" name="name" value="{{$usuario->name}}"></p>
    @foreach ($errors->get('name') as $error)
        <div>{{$error}}</div>
    @endforeach
    <p>Email:       <input type="email" name="email" value="{{$usuario->email}}"></p>
    @foreach ($errors->get('email') as $error)
        <div>{{$error}}</div>
    @endforeach
    <p>Password:    <input type="text" name="password"></p>
    @foreach ($errors->get('password') as $error)
        <div>{{$error}}</div>
    @endforeach
    <input type="submit" value="Enviar">
</form>
<a href="/usuario/{{ $usuario->id }}">Volver</a>
