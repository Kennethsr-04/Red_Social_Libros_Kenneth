
<div class="container">
    <h1>Listado de Libros</h1>
    <ul>
        @foreach($libros as $libro)
            <li>
                <a href="{{ route('libros.show', $libro->id) }}">
                    {{ $libro->titulo }} - {{ $libro->autor }}
                </a>
            </li>
        @endforeach
    </ul>
    
</div>



