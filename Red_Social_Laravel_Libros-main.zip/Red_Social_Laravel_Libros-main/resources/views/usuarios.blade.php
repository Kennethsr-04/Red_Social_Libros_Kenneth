<h1>Perfil de los usuarios</h1>

@auth

<p>Hola, {{ Auth::user()->name }}</p>

@endauth

<ul>

    @foreach($usuarios as $usuario)
        <li>
            <a href="/usuario/{{$usuario->id}}">
                {{$usuario->name}} ({{$usuario->email}})
            </a>
            <a href="/usuario/{{$usuario->id}}/editar">
                Editar
            </a>
            <form action="/usuario/{{$usuario->id}}" method="POST">
                @csrf
                @method('DELETE')
                <input type="submit" value="Borrar">
            </form>
        </li>
    @endforeach

</br>
    <a href="/usuarios/crear">Crear usuario</a>
</ul>

</br>
<ul>
    <a href="/libros">Listado de libros</a>
</ul>
</br>


<form method="POST" action="{{ route('logout') }}">

    @csrf
    <input type="submit" value="Cerrar sesión"> 
    
</form>
