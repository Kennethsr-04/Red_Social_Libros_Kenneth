<div class="container">
    <h2>Título: {{ $libro->Título }}</h2>
    <div>Género: {{ $libro->Género }}</div>
    <div>Editorial: {{ $libro->Editorial }}</div>
    <div style="margin-top: 15px; display: flex; gap: 10px;">
        <form action="{{ route('libros.edit', $libro->Id) }}" method="GET">
            <button type="submit">
                Editar Libro
            </button>
        </form>

        <form action="{{ route('libros.destroy', $libro->Id) }}" method="POST" onsubmit="return confirm('¿Estás seguro de que quieres borrar este libro? Esta acción no se puede deshacer.');">
            @csrf
            @method('DELETE')
            <button type="submit">
                Borrar Libro
            </button>
        </form>
    </div>
    

    <hr>

    <h2>Valoraciones</h2>
    @if($libro->valoraciones->isEmpty())
    @else
        <ul>
            @foreach($libro->valoraciones as $valoracion)
                <li>
                    <strong>{{ $valoracion->user->name }}</strong> ({{ $valoracion->valoracion }}/5 estrellas): <br>
                    {{ $valoracion->comentario }}
                </li>
            @endforeach
        </ul>
    @endif

    <hr>
    
    @if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    <form action="{{ route('libros.valorar', $libro->Id) }}" method="POST">
        @csrf
        
        <div>
            <label>Puntuación (1 al 5):</label>
            <input type="number" name="puntuacion" min="1" max="5" value="{{ old('puntuacion') }}">
            @error('puntuacion')
                <span style="color: red;">{{ $message }}</span>
            @enderror
        </div>

        <div>
            <label>Comentario:</label><br>
            <textarea name="comentario" rows="3">{{ old('comentario') }}</textarea>
            @error('comentario')
                <span style="color: #FFF;"><br>{{ $message }}</span>
            @enderror
        </div>

        <button type="submit">Enviar</button>
    <ul>
        <a href="/libros">Volver</a>
    </ul>
    </form>
</div>


