<h1>Creación de usuario</h1>

<form action="/usuarios" method="POST">
    @csrf
    <p>Nombre:      <input type="text" name="name"></p>
    @foreach ($errors->get('name') as $error)
        <div>{{$error}}</div>
    @endforeach
    <p>Email:       <input type="email" name="email"></p>
    @foreach ($errors->get('email') as $error)
        <div>{{$error}}</div>
    @endforeach
    <p>Password:    <input type="text" name="password"></p>
    @foreach ($errors->get('password') as $error)
        <div>{{$error}}</div>
    @endforeach
    <input type="submit" value="Enviar">
</form>

<a href="/usuarios">Volver</a>

<!--
@if($errors->any())
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{$error}}</li>
            @endforeach
        </ul>
@endif
-->

