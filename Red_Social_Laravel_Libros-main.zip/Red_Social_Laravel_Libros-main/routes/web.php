<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

use App\Http\Controllers\UserController;

Route::middleware('auth')->group(function () {
    
Route::get('/usuarios', [UserController::class, 'usuarios']);
Route::get('/usuarios/crear', [UserController::class, 'crear']);
Route::post('/usuarios', [UserController::class, 'usuarios1']);
Route::get('/usuario/{id}', [UserController::class, 'buscar']);
Route::get('/usuario/{id}/editar', [UserController::class, 'editar']);
Route::put('/usuario/{id}', [UserController::class, 'editar1']);
Route::delete('/usuario/{id}', [UserController::class, 'borrar']);
Route::get('/hola', [UserController::class, 'hola']);
Route::get('/hola/{nombre}', [UserController::class, 'hola2']);

});

use App\Http\Controllers\LibroController;

Route::middleware(['auth'])->group(function () {
    Route::get('/libros', [LibroController::class, 'index'])->name('libros.index');
    Route::get('/libros/crear', [LibroController::class, 'create'])->name('libros.create');
    Route::post('/libros', [LibroController::class, 'store'])->name('libros.store');
    Route::get('/libros/{id}', [LibroController::class, 'show'])->name('libros.show');
    Route::get('/libros/{id}/editar', [LibroController::class, 'edit'])->name('libros.edit');
    Route::delete('/libros/{id}', [LibroController::class, 'destroy'])->name('libros.destroy');
    Route::put('/libros/{id}', [LibroController::class, 'update'])->name('libros.update');
    Route::post('/libros/{id}/valorar', [LibroController::class, 'storeValoracion'])->name('libros.valorar');
});


