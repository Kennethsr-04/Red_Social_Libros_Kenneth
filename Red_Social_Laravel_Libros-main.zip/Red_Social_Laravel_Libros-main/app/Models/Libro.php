<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Libro extends Model
{
    protected $primaryKey = 'Id';

    public $timestamps = false;

    protected $fillable = [
        'Título', 'Autor_id', 'Género', 'Editorial', 'Páginas', 'Año', 'Precio'
    ];

    public function valoraciones()
    {
        return $this->hasMany(Valoracion::class, 'libro_id', 'Id');
    }
}
