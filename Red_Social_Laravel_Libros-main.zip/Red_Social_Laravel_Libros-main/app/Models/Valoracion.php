<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Valoracion extends Model
{
    protected $table = 'valoracion'; 

    const UPDATED_AT = null;

    protected $fillable = ['libro_id', 'user_id', 'comentario', 'valoracion'];

    public function libro()
    {
        return $this->belongsTo(Libro::class, 'libro_id', 'Id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
