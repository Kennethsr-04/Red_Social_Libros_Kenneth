<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Libro;
use App\Models\Valoracion;
use App\Http\Requests\StoreValoracionRequest;
use Illuminate\Support\Facades\Auth;

class LibroController extends Controller
{
    public function index()
    {
        $libros = Libro::all(); 
        return view('libros_index', compact('libros'));
    }

    public function create()
    {
        return view('libros_create');
    }

    public function store(\Illuminate\Http\Request $request)
    {
        $request->validate([
            'Título' => 'required|string|max:255',
            'Autor_id' => 'required|integer',
        ]);

        Libro::create([
            'Título' => $request->Título,
            'Autor_id' => $request->Autor_id,
            'Género' => $request->Género,
            'Editorial' => $request->Editorial,
            'Páginas' => $request->Páginas,
            'Año' => $request->Año,
            'Precio' => $request->Precio,
        ]);
        return redirect()->route('libros.index');
    }

    public function edit($id)
    {
        $libro = Libro::findOrFail($id);
        return view('libros_edit', compact('libro'));
    }

    public function update(\Illuminate\Http\Request $request, $id)
    {
        $request->validate([
            'Título' => 'required|string|max:255',
            'Autor_id' => 'required|integer',
            'Editorial' => 'nullable|string|max:50',
        ]);

        $libro = Libro::findOrFail($id);
        $libro->update([
            'Título' => $request->Título,
            'Autor_id' => $request->Autor_id,
            'Género' => $request->Género,
            'Editorial' => $request->Editorial,
            'Páginas' => $request->Páginas,
            'Año' => $request->Año,
            'Precio' => $request->Precio,
        ]);
        return redirect()->route('libros.show', $libro->Id)->with('success', 'Libro actualizado correctamente');
    }

    public function show($id)
{
    $libro = Libro::with('valoraciones')->where('Id', $id)->firstOrFail();

    return view('libros_show', compact('libro'));
}

public function storeValoracion(StoreValoracionRequest $request, $id)
{
    $libro = Libro::findOrFail($id);
    $userId = Auth::id();

    $yaValorado = Valoracion::where('libro_id', $libro->Id)
                            ->where('user_id', $userId)
                            ->exists();

    if ($yaValorado) {
        return redirect()->route('libros.show', $libro->Id)
                         ->withErrors(['']);
    }

    Valoracion::create([
        'libro_id' => $libro->Id,
        'user_id' => $userId,
        'comentario' => $request->comentario,
        'valoracion' => $request->puntuacion
    ]);

    return redirect()->route('libros.show', $libro->Id);
}

public function destroy($id)
    {
        // Buscamos el libro
        $libro = Libro::findOrFail($id);
        
        // Lo borramos de la base de datos
        $libro->delete();

        // Volvemos al listado principal con un mensaje
        return redirect()->route('libros.index')->with('success', 'Borrado correctamente');
    }
}

