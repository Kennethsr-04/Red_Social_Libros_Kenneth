<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests\StoreRequest;

use App\Http\Requests\UpdateRequest;

use App\Models\User;

class UserController extends Controller
{
    //  Controller methods will go here

    public function usuarios() {

    $usuarios = User::all();

    return view('usuarios', [
        "usuarios" => $usuarios
    ]);
}

    public function crear() {

    return view('usuarios_crear', [
    ]);
}

    public function buscar($id) {

    $usuario = User::find($id);

    return view('usuario', [
        "usuario" => $usuario
    ]);
}

    public function editar($id){

    $usuario = User::findOrFail($id);

    return view('usuario_editar', [
        "usuario" => $usuario
    ]);
}

    public function usuarios1(StoreRequest $request) {

    User::create([
        "name" => $request->name,
        "email" => $request->email,
        "password" => bcrypt($request->password)
    ]);

    return redirect('/usuarios');

}

    public function editar1(UpdateRequest $request, $id) {

    $usuario = User::findOrFail($id);

        $usuario->name = $request->name;
        $usuario->email = $request->email;

    if ($request->password) {
        $usuario->password = bcrypt($request->password);
    }   

    $usuario->save();

    return redirect('/usuarios');
}

    public function borrar($id) {

    $usuario = User::findOrFail($id);
    $usuario->delete();

    return redirect('/usuarios');
}

    public function welcome() {
    return view('welcome');
}

    public function hola() {
    $nombre = "David";
    return view('hola', [ 
        "nombre" => $nombre 
    ]);
}

    public function hola2($nombre) {
    return view('hola', [ 
        "nombre" => $nombre 
    ]);
}
    
}
