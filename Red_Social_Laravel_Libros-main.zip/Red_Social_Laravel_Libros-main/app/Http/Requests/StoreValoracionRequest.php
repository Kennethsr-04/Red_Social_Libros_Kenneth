<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreValoracionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
        'comentario' => 'required|string|max:1000',
        'puntuacion' => 'required|integer|min:1|max:5',
        ];
    }
    public function messages()
    {
    return [
        'comentario.required' => 'Comentario vacío',
        'puntuacion.min' => 'Pon al menos una estrella',
        'puntuacion.max' => 'Cinco strellas máximo',
    ];
}
}
